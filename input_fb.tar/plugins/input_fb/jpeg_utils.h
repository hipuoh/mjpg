int compress_yuyv_to_jpeg(struct vdIn *vd, unsigned char *buffer, int size, int quality);
int compress_yuv420_to_jpeg(struct vdIn *vd, unsigned char *buffer, int size, int quality);
int compress_rgb888_to_jpeg(struct vdIn *vd, unsigned char *buffer, int size, int quality);
